import type { LucideIcon } from 'lucide-react';

export type NavItem = {
  name: string;
  href: string;
};

export type Service = {
  id: string;
  icon: LucideIcon;
  title: string;
  description: string;
};

export type Testimonial = {
  name: string;
  image: string | null;
  testimonial: string;
  rating: number;
  time: string;
  fallbackColor?: string;
};

export type Offer = {
    id: string;
    title: string;
    discount: string;
    disclaimer: string;
};

export type TeamMember = {
    id: string;
    name: string;
    role: string;
    experience: string;
    image: string;
    description: string;
    certifications: string[];
};

export type WhyChooseUsItem = {
  id: string;
  title: string;
  content: string;
  icon: LucideIcon;
  image?: string;
};

export type FaqItem = {
    id: string;
    question: string;
    answer: string;
    list?: { title: string; detail: string }[];
    conclusion?: string;
};

export type ChatMessage = {
  id: string;
  role: 'user' | 'bot';
  content: React.ReactNode;
  timestamp: string;
};
